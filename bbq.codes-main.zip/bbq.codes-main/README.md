# 🧬 bbq.codes Kaynak kodu.

Yeni başlayanlar ve örnek almak isteyenler için basit ve sade bir websitesi.<br>
Sorunuz/Sıkıntınız olursa GitHub profilimdeki bağlantılardan bana ulaşabilirsiniz.

## 📷 Ekran Görüntüsü

### 💻 Bilgisayar Görünümü
<img src="https://barbecue.is-pretty.cool/9wxixem.png">

### 📱 Telefon Görünümü

<img src="https://barbecue.is-pretty.cool/4XnyPak.png">

## https://github.com/barbecue tarafından yapılmıştır iznim olmadan veya adım geçirilmeden paylaşmayın.
